Thank you for buying our asset
Post Processing Profiles 3.0

!!!Please delete Post Processing-2 folder and import Post processing-2 from Unity Package Manager!!! (IF you use > Unity 2018 version)
(https://docs.unity3d.com/Packages/com.unity.package-manager-ui@1.8/manual/index.html)

How to use:
Move Blood, Camera1, Camera_BW, Ice prefab to your scene.
Or move ALL_OtherProfiles prefab to your scene, after this add profile to Post Process Volume (script) -> Profile.


ChangeLog 3.0:
- Profiles fix
- New profiles for PP2: Autumn, Coziness, Crazy, Dark, Horror2, Movie2, Movie3, Purple, Russian, Vice2.


https://www.gestgames.net/
Got any questions? Contact me now!
yrayushka@yahoo.com