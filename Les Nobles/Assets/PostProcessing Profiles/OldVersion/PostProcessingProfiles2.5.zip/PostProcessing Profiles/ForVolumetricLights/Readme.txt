For realistic result use VolumetricLights, it's in open source.
( https://github.com/SlightlyMad/VolumetricLights ). 

VolumetricLightRenderer.cs put on camera.
VolumetricLight.cs put on all Lights in scene.
Tutorial: https://www.youtube.com/watch?v=H5v_X1k02U0